package geometrie;

public abstract class Polygone extends FigureGeometrique 
{	
	/* Methodes */
	public abstract String toString();
}
