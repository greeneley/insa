package geometrie;

public class Pentagone extends Polygone {
	
	/* Methodes */
	public String toString()
	{
		return "C'est un pentagone";
	}

}
