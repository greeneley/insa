package geometrie;

public class Triangle extends Polygone {
	
	public String toString()
	{
		return "C'est un triangle";
	}

}
