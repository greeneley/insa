#include <stdio.h>
#include <ctype.h>

#include "dict.h"

#include "CodeClient.hc"

int
main(argc,argv)
int argc;
char *argv[];
{

	fonctionClient();

}

