
#define MAXSTRING 256
#define DICTSIZ 100

struct DictRecord {
	int longueur;
	char donnee[MAXSTRING];
};
typedef struct DictRecord DictRecord;
