#include <stdio.h>
#include <ctype.h>
#include "dict.h"

#include "DictProcedures.hc"
